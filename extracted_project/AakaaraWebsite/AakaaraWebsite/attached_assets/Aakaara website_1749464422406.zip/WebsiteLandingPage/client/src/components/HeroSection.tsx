export default function HeroSection() {
  return null;
}
